Import Sys From "lib/lang/system.bas"
Import JSArray From "lib/lang/array.bas"
Import Dom From "lib/web/dom.bas"
Import GXS From "https://gxapi.boxgaming.co/v0/gxs.bas"
Import GXSUI From "gxsui/ui.bas"

Option Explicit
Randomize Timer

' Constants
Const GAME_NAME = "GX Laser Tag"
Const MSG_CTRL_STATE = 1001, MSG_UPDATE_PLAYERS = 1002, MSG_REGISTER_PLAYER = 1003
Const ACCELERATION = 10, WALK_SPEED = 100, ANIMATE_SPEED = 10
Const LASER_SPEED = 450, STUN_MILLIS = 1000
Const DIR_RIGHT = 1, DIR_LEFT = 2, DIR_DOWN = 3, DIR_UP = 4
Const ETYPE_PLAYER = 1, ETYPE_BULLET = 2
Const COLLISION_LAYER = 6, COLLISION_TILE = 2121, SPAWN_TILE = 109
Const SND_LASER = 1
Const GAME_LENGTH = 180
Const INTERMISSION_LENGTH = 30

' Type definitions
Type ControlState: As Integer a, s, w, d, f: End Type
Type Position: As Integer x, y: End Type
Type GameSound: As Integer s, x, y: End Type
Type Player
    As Integer eid, disabled, x, y, vx, vy, direction
    As Integer hitFrame, frame, seq, animateSpeed, hits, tags
    As String cid, name
    As ControlState cstate
End Type
Type Bullet
    As Integer eid, visible, x, y, vx, vy, seq, frame
    As Player shooter
End Type

' Register callback methods for game server events
GXS.RegisterEvent GXS.HOST_GAME, @OnHostGame
GXS.RegisterEvent GXS.JOIN_GAME, @OnJoinGame
GXS.RegisterEvent GXS.CLIENT_DISCONNECTED, @OnClientDisconnect
GXS.RegisterEvent GXS.ERROR, @OnError
GXS.RegisterEvent GXS.CLOSE, @OnClose
GXS.RegisterEvent GXS.HOST_DISCONNECTED, @OnHostDisconnect
GXS.RegisterEvent GXSUI.MSG_CHAT, @OnChat
GXS.RegisterEvent MSG_CTRL_STATE, @OnCtrlState
GXS.RegisterEvent MSG_UPDATE_PLAYERS, @OnUpdatePlayers
GXS.RegisterEvent MSG_REGISTER_PLAYER, @OnRegisterPlayer
' Register callback methodsfor game UI events
GXSUI.RegisterEvent GXSUI.EVENT_HOST_GAME, @OnStartHostGame
GXSUI.RegisterEvent GXSUI.EVENT_JOIN_GAME, @OnStartJoinGame

' Shared game variables
Dim Shared As String pname
Dim Shared As Integer started, connecting, intermission, keymap()
Dim Shared As Integer phaseStart, secondsRemaining
Dim Shared As Long hostFrame, lastGameSync
ReDim Shared As Object gameList(0)
ReDim Shared As Position spawnPoints(0)
ReDim Shared players(0) As Player
Dim Shared pmap() As Player
Dim Shared As Object tsounds, plist
tsounds = JSArray.Create

' Create the scene
GXSceneCreate 320, 200
GXSceneScale 3

' Load the map
GXMapLoad "interior-test.gxm"
GXMapLayerVisible COLLISION_LAYER, GX_FALSE
LoadSpawnPoints
GXSceneConstrain GXSCENE_CONSTRAIN_TO_MAP
GXEntityRenderMode GXENTITY_RENDER_TOPDOWN

' Initialize the lasers
Dim Shared bullets(20) As Bullet
Dim Shared bmap() As Bullet
Dim i As Integer
For i = 1 To UBound(bullets)
    bullets(i).eid = GXEntityCreate("bullet.png", 32, 32, 1)
    GXEntityType bullets(i).eid, ETYPE_BULLET
    GXEntityPos bullets(i).eid, -100, -100
    GXEntityVisible bullets(i).eid, GX_FALSE
    GXEntityMapLayer bullets(i).eid, 3
    bmap(bullets(i).eid) = bullets(i)
Next i
' Create a bank of sound objects for each type of sound to allow
' them to be played simultanously
Dim Shared sounds(1, 20) As Long
For i = 1 To UBound(sounds, 2)
    sounds(SND_LASER, i) = GXSoundLoad("laser.wav")
Next i
sounds(SND_LASER, 0) = 1 ' next sound index

GXSUI.Init

' Start the game
Sys.SetTimeout @SendPlayerUpdates, 16
GXSceneStart

' When the scene ends, exit the program
System

' Main game event handler
Sub GXOnGameEvent (e As GXEvent)
    Select Case e.event
        Case GXEVENT_UPDATE: OnUpdate e
        Case GXEVENT_DRAWSCREEN: OnDrawScreen e
        Case GXEVENT_COLLISION_TILE: OnTileCollision e
        Case GXEVENT_COLLISION_ENTITY: OnEntityCollision e
    End Select
End Sub

' Play a sound given its id and, optionally, the volume level
Sub PlaySound (sidx As Integer, volume)
    If volume = undefined Then volume = 50
    GXSoundVolume sounds(sidx, sounds(sidx, 0)), volume
    GXSoundPlay sounds(sidx, sounds(sidx, 0))
    sounds(sidx, 0) = sounds(sidx, 0) + 1
    If sounds(sidx, 0) > UBound(sounds, 2) Then sounds(sidx, 0) = 1
End Sub

' Play the specified game sound setting the volume relative to the
' distance of the sound origin from the player
Sub PlaySoundAt (gs As GameSound)
    Dim p As Player
    Dim As Integer volume, distance, px, py
    p = pmap(GXS.ClientId)
    px = Abs(GXEntityX(p.eid) - gs.x)
    py = Abs(GXEntityY(p.eid) - gs.y)
    If px > py Then distance = px Else distance = py
    
    volume = 75 - distance \ 8
    If volume > 0 Then PlaySound gs.s, volume
End Sub

' Scan through each tile in the collision layer looking for
' player spawn tiles and add them to the spawnPoints array
Sub LoadSpawnPoints
    Dim As Integer row, col, tile, idx
    For row = 0 To GXMapRows - 1
        For col = 0 To GXMapColumns - 1
           tile = GXMapTile(col, row, COLLISION_LAYER)
           If tile = SPAWN_TILE Then
               idx = UBound(spawnPoints) + 1
               ReDim Preserve spawnPoints(idx) As Position
               spawnPoints(idx).x = col * GXTilesetWidth
               spawnPoints(idx).y = row * GXTilesetHeight
           End If
        Next col
    Next row
End Sub

' This is the main game loop update method which is called each frame
Sub OnUpdate (e As GXEvent)
    If connecting Then Exit Sub ' Nothing else to do here yet
    
    ' See if the user has pressed the H or J key to start the game
    If Not started Then 
        If KeyPress(GXKEY_H) Then
            GXSUI.ShowHostGameDialog
            
        ElseIf KeyPress(GXKEY_J) Then
            GXSUI.ShowGameListDialog GAME_NAME
        End If
        Exit Sub
    End If
    
    If KeyPress(GXKEY_C) Then GXSUI.FocusChat
    If KeyPress(GXKEY_I) Then GXSUI.ShowInviteDialog
    If KeyPress(GXKEY_F) Then Dom.RequestFullscreen Dom.Container
    
    ' If the player input control state has changed since the last frame
    ' send the current input control state to the host
    Dim cstate As ControlState
    cstate.a = GXKeyDown(GXKEY_A)
    cstate.s = GXKeyDown(GXKEY_S)
    cstate.w = GXKeyDown(GXKEY_W)
    cstate.d = GXKeyDown(GXKEY_D)
    cstate.f = KeyPress(GXKEY_K)
    Dim player As Player
    player = pmap(GXS.ClientId)
    If PlayerInputChanged(player.cstate, cstate) Then
        GXS.SendHostMessage MSG_CTRL_STATE, cstate
        player.cstate = cstate
    End If
    
    Dim i As Integer
    For i = 1 To UBound(players)
        Dim p As Player
        p = players(i)
        If p.disabled Then Continue
        
        ' If this is the game host then handle the player
        ' inputs for each player
        If GXS.IsHost Then HandlePlayerInput p
        
        ' If the player has been hit, toggle the entity visibility
        ' for a brief period
        If p.hitFrame Then
            If MillisSince(p.hitFrame, hostFrame) < STUN_MILLIS Then
                If GXFrame Mod 2 = 0 Then
                    GXEntityVisible p.eid, GX_TRUE
                Else
                    GXEntityVisible p.eid, GX_FALSE
                End If
            Else
                p.hitFrame = 0
            End If
        Else
            GXEntityVisible p.eid, GX_TRUE
        End If
   Next i
    
   If KeyPress(GXKEY_END) Then
       GXSUI.ShowMessageBox "Are you sure you wish to leave the game?", GXSUI.MB_YESNO, @OnExitGame
    End If
End Sub

' Update the seconds remaining in the current phase and handle transitioning
' between rounds of play and intermission
Sub UpdateTime
    Dim phaseLength As Integer
    If intermission Then phaseLength = INTERMISSION_LENGTH Else phaseLength = GAME_LENGTH
    secondsRemaining = phaseLength - (Sys.TimeInMillis - phaseStart) \ 1000
    If secondsRemaining < 1 Then
        intermission = Not intermission
        phaseStart = Sys.TimeInMillis
        If intermission Then
            ReSortPlayers
        Else
            ResetPlayers
        End If
    End If 
End Sub

' Re-sort the player list by most tags and least hits for the leaderboard
Sub ReSortPlayers
    plist = JSArray.Create(players)
    JSArray.Sort plist, @SortPlayers
End Sub

' This is the callback function that is sent to the Sort method
' used to compare two elements in the list
Function SortPlayers (a As Object, b As Object)
    Dim result As Integer
    If a.tags = b.tags Then
        result = a.hits - b.hits
    Else
        result = b.tags - a.tags
    End If
    SortPlayers = result
End Function

Sub OnExitGame
    GXS.LeaveGame
    GXSUI.PutMessage "You have left the game."
    started = GX_FALSE
End Sub

' Test to see whether any player inputs have changed from the previous state
Function PlayerInputChanged(cs1, cs2)
    Dim As Integer changed 
    If cs1 = undefined Then: changed = GX_TRUE
    ElseIf cs1.a <> cs2.a Then: changed = GX_TRUE 
    ElseIf cs1.s <> cs2.s Then: changed = GX_TRUE 
    ElseIf cs1.w <> cs2.w Then: changed = GX_TRUE 
    ElseIf cs1.d <> cs2.d Then: changed = GX_TRUE 
    ElseIf cs1.f <> cs2.f Then: changed = GX_TRUE 
    End If
    PlayerInputChanged = changed
End Function

' Detects if a key has been pressed and released
Function KeyPress (k)
    Dim pressed As Integer
    If keymap(k) And Not GXKeyDown(k) Then
        pressed = GX_TRUE
    End If
    keymap(k) = GXKeyDown(k)
    KeyPress = pressed
End Function

' Event handler to detect whether a collision has occured between an entity and tile
Sub OnTileCollision (e As GXEvent)
    If Not GXS.IsHost Then Exit Sub
    
    Dim tile As Integer
    tile = GXMapTile(e.collisionTileX, e.collisionTileY, COLLISION_LAYER)
    If tile = COLLISION_TILE Then
        e.collisionResult = GX_TRUE
        
        If GXEntityType(e.entity) = ETYPE_BULLET Then
            ResetBullet e.entity
        End If
    End If
End Sub

' Event handler to detect whether a collision has occurred between two entities
Sub OnEntityCollision (e As GXEvent)
    If Not GXS.IsHost Then Exit Sub
    
    If GXEntityType(e.entity) = ETYPE_PLAYER And GXEntityType(e.collisionEntity) = ETYPE_PLAYER Then
        e.collisionResult = GX_TRUE
        
    ElseIf GXEntityType(e.entity) = ETYPE_BULLET And GXEntityType(e.collisionEntity) = ETYPE_PLAYER Then
        
        Dim As Bullet b
        Dim As Player p
        p = pmap(e.collisionEntity)
        b = bmap(e.entity)
        If b.shooter = p Then Exit Sub  ' Can't shoot yourself
        
        ' Enable a short window of invincibility after being hit
        If p.hitFrame Then
            If MillisSince(p.hitFrame) < STUN_MILLIS Then Exit Sub
        End If
        
        If GXEntityVX(e.entity) > 0 Then
            GXEntityVX e.collisionEntity, 100
        ElseIf GXEntityVX(e.entity) < 0 Then
            GXEntityVX e.collisionEntity, -100
        ElseIf GXEntityVY(e.entity) > 0 Then
            GXEntityVY e.collisionEntity, 100
        ElseIf GXEntityVY(e.entity) < 0 Then
            GXEntityVY e.collisionEntity, -100
        End If
        
        b.shooter.tags = b.shooter.tags + 1
        p.hits = p.hits + 1
        p.hitFrame = GXFrame
        ResetBullet e.entity
    End If
End Sub

' Returns the number of milliseconds which have elapsed since a given frame
Function MillisSince (frame As Integer, startFrame)
    If startFrame = undefined Then startFrame = GXFrame
    MillisSince = Fix(((startFrame - frame) / GXFrameRate) * 1000)
End Function

Sub ResetBullet (eid As Integer)
    GXEntityPos eid, -100, -100
    GXEntityVisible eid, GX_FALSE 
    GXEntityVX eid, 0
    GXEntityVY eid, 0
End Sub

Sub HandlePlayerInput (p As Player)
    Dim aoffset As Integer
    
    ' If the player has pressed the fire button, shoot a laser
    If p.cstate.f And Not intermission Then
        Shoot p
        p.cstate.f = GX_FALSE
        p.shootFrame = GXFrame
    End If
    
    If GXFrame - p.shootFrame < 20 Then
        aoffset = 4
    End If
    
    ' If a movement key is being pressed, move and animate
    ' the player entity accordingly
    Dim As Integer vx, vy
    vx = GXEntityVX(p.eid)
    If p.cstate.d Then
        p.direction = DIR_RIGHT
        GXEntityVX p.eid, CInc(vx, ACCELERATION, WALK_SPEED)
        GXEntityAnimate p.eid, p.direction + aoffset, ANIMATE_SPEED
        p.animateSpeed = ANIMATE_SPEED

    ElseIf p.cstate.a Then
        p.direction = DIR_LEFT
        GXEntityVX p.eid, CDec(vx, ACCELERATION, -WALK_SPEED)
        GXEntityAnimate p.eid, p.direction + aoffset, ANIMATE_SPEED
        p.animateSpeed = ANIMATE_SPEED
    Else
        If vx > 0 Then
            vx = vx - 10
            If vx < 0 Then vx = 0
        ElseIf vx < 0 Then
            vx = vx + 10
            If vx > 0 Then vx = 0
        End If
        GXEntityVX p.eid, vx
    End If

    vy = GXEntityVY(p.eid)
    If p.cstate.s Then
        p.direction = DIR_DOWN
        GXEntityVY p.eid, CInc(vy, ACCELERATION, WALK_SPEED)
        GXEntityAnimate p.eid, p.direction + aoffset, ANIMATE_SPEED
        p.animateSpeed = ANIMATE_SPEED
    ElseIf p.cstate.w Then
        p.direction = DIR_UP
        GXEntityVY p.eid, CDec(vy, ACCELERATION, -WALK_SPEED)
        GXEntityAnimate p.eid, p.direction + aoffset, ANIMATE_SPEED
        p.animateSpeed = ANIMATE_SPEED
    Else
        If vy > 0 Then
            vy = vy - 10
            If vy < 0 Then vy = 0
        ElseIf vy < 0 Then
            vy = vy + 10
            If vy > 0 Then vy = 0
        End If
        GXEntityVY p.eid, vy
        
    End If

    If GXEntityVX(p.eid) = 0 And GXEntityVY(p.eid) = 0 Then 
        GXEntityAnimateStop p.eid
        GXEntityFrameSet p.eid, p.direction + aoffset, GXEntityFrame(p.eid)
        p.animateSpeed = 0
    End If
    
    ' Handle portal doors
    If GXEntityY(p.eid) < -17 Then
        GXEntityPos p.eid, 567, 748
    ElseIf GXEntityY(p.eid) > 750 Then
        If Rnd*2 Mod 2 < 1 Then
            GXEntityPos p.eid, 1038, -16
        Else
            GXEntityPos p.eid, 1400, -4
        End If
    ElseIf GXEntityX(p.eid) < -15 Then
        GXEntityPos p.eid, 1599, 270
    ElseIf GXEntityX(p.eid) > 1600 Then
        GXEntityPos p.eid, -14, 247
    End If
   
End Sub

Function CInc (value, increment, max)
    value = value + increment
    If value > max Then value = max
    CInc = value
End Function

Function CDec (value, decrement, min)
    value = value - decrement
    If value < min Then value = min
    CDec = value
End Function

' Finds the next available laser entity and fires it in the direction
' the player is facing, and plays a corresponding sound effect
Sub Shoot (p As Player)
    ' Don't allow the player to shoot if they are still stunned
    If MillisSince(p.hitFrame, hostFrame) < STUN_MILLIS Then Exit Sub
    
    Dim As Integer i, b
    For i = 1 To UBound(bullets)
        b = bullets(i).eid
        If Not GXEntityVisible(b) Then
            bullets(i).shooter = p
            GXEntityVisible b, GX_TRUE
            If p.direction = DIR_LEFT Then
                GXEntityPos b, GXEntityX(p.eid) - 20, GXEntityY(p.eid) - 3
                GXEntityFrameSet b, 5, 1
                GXEntityVX b, -LASER_SPEED
                GXEntityCollisionOffset b, 15, 15, 15, 15
                
            ElseIf p.direction = DIR_RIGHT Then
                GXEntityPos b, GXEntityX(p.eid) + 5, GXEntityY(p.eid) - 3
                GXEntityFrameSet b, 5, 1
                GXEntityVX b, LASER_SPEED
                GXEntityCollisionOffset b, 15, 15, 15, 15
                
            ElseIf p.direction = DIR_UP Then
                If GXEntityVX(p.eid) > 0 Then
                    GXEntityPos b, GXEntityX(p.eid) + 4, GXEntityY(p.eid) - 15
                    GXEntityFrameSet b, 3, 1
                    GXEntityVX b, LASER_SPEED
                ElseIf GXEntityVX(p.eid) < 0 Then
                    GXEntityPos b, GXEntityX(p.eid) -18, GXEntityY(p.eid) - 15
                    GXEntityFrameSet b, 7, 1
                    GXEntityVX b, -LASER_SPEED
                Else 
                    GXEntityPos b, GXEntityX(p.eid) - 2, GXEntityY(p.eid) - 15
                    GXEntityFrameSet b, 1, 1
                End If
                GXEntityVY b, -LASER_SPEED
                GXEntityCollisionOffset b, 15, 15, 15, 15
            Else
                If GXEntityVX(p.eid) > 0 Then
                    GXEntityPos b, GXEntityX(p.eid) - 1, GXEntityY(p.eid) + 12
                    GXEntityFrameSet b, 7, 1
                    GXEntityVX b, LASER_SPEED
                ElseIf GXEntityVX(p.eid) < 0 Then
                    GXEntityPos b, GXEntityX(p.eid) - 18, GXEntityY(p.eid) + 12
                    GXEntityFrameSet b, 3, 1
                    GXEntityVX b, -LASER_SPEED
                Else 
                    GXEntityPos b, GXEntityX(p.eid) - 12, GXEntityY(p.eid) + 12
                    GXEntityFrameSet b, 1, 1
                End If
                GXEntityVY b, LASER_SPEED
                GXEntityCollisionOffset b, 15, 15, 15, 15
            End If
            
            Dim snd As GameSound
            snd.s = SND_LASER
            snd.x = GXEntityX(p.eid)
            snd.y = GXEntityY(p.eid)
            JSArray.Push tsounds, snd
            PlaySoundAt snd
            Exit Sub
        End If
    Next i
End Sub

' Handles custom screen drawing
Sub OnDrawScreen (e As GXEvent)
    ' Show the appropriate menu, based on the current game state
    If Not started Then
        DrawText GXSceneWidth - 85, 5, _
            "H - Host Game" + GX_CRLF + _
            "J - Join Game"
            
    ElseIf GXSUI.IsChatting Then
        DrawText GXSceneWidth - 135, 5, _
            "Enter - Send Message" + GX_CRLF + _
            "  Tab - Return to Game"
    Else
        DrawText GXSceneWidth - 105, 5, _
            "WSAD - Move" + GX_CRLF + _
            "   K - Shoot" + GX_CRLF + _
            "   I - Invite" + GX_CRLF + _
            "   C - Chat" + GX_CRLF + _
            "   F - Fullscreen" + GX_CRLF + _
            " END - Exit Game"
    End If
    
    ' For each player, display the player's name just above their head and
    ' display the number of tags the player has made and the number of hits
    ' they have received under the player sprite.
    Dim As Integer i, cx, nx, tx, ty
    Dim As String tags, hits
    For i = 1 To UBound(players)
        Dim p As Player
        p = players(i)
        cx = GXEntityX(p.eid) + GXEntityWidth(p.eid)\2 - GXSceneX
        nx = cx - (Len(p.name) * GXFontWidth(GXFONT_DEFAULT))/2 
        DrawText nx, GXEntityY(p.eid) - 9 - GXSceneY, p.name
        tags = Trim$(Str$(p.tags))
        hits = Trim$(Str$(p.hits))
        tx = cx - Len(tags) * GXFontWidth(GXFONT_DEFAULT) - 2 
        ty =  GXEntityY(p.eid) + GXEntityHeight(p.eid) - GXSceneY + 1
        DrawText tx, ty, tags 
        DrawText cx + 2, ty, hits
    Next i
    
    If started Then
        If intermission Then Line (0, 0)-(Width, Height), RGBA(10, 10, 10, 150), BF
        Dim seconds, minutes
        minutes = secondsRemaining \ 60
        seconds = secondsRemaining - minutes * 60
        Dim prefix As String
        If intermission Then prefix = "Next Game "
        If secondsRemaining > 10 Then
            DrawText 5, 5, prefix + Right$("00" + minutes, 2) + ":" + Right$("00" + seconds, 2)
        ElseIf GXFrame Mod 15 > 2 Then
            DrawText 5, 5, prefix + Right$("00" + minutes, 2) + ":" + Right$("00" + seconds, 2)
        End If
        
        If intermission Then
            Dim p As Player
            Dim y As Integer
            y = 30
            DrawText 5, 20, "Player       Tags   Hits"
            Dim As Integer i
            For i = 0 To JSArray.Length(plist) - 1
                p = JSArray.Item(plist, i)
                If p.disabled Then Continue
                DrawText 5, y, _
                    Left$(p.name + Space$(12), 12) + " " + _
                    Left$(p.tags + Space$(6), 6) + " " + _
                    Left$(p.hits + Space$(6), 6)
                y = y + 10
            Next i
        End If
    End If
End Sub

' Draw specified text with a dropshadow style
Sub DrawText (x As Integer, y As Integer, text As String)
    GXDrawText GXFONT_DEFAULT_BLACK, x + 1, y + 1, text
    GXDrawText GXFONT_DEFAULT, x, y, text
End Sub

' This method sends game updates out to all players at the end of each frame.
' It is fired by the GXEVENT_AFTERPAINT event as this is the last event fired
' in the game loop.
Sub SendPlayerUpdates
    If started And GXS.IsHost Then
        UpdateTime
        
        ' Set the current frame of the host.  This will give a consistent
        ' reference that all clients can use for calculating elapsed time.
        Dim msg As Object
        msg.frame = GXFrame
        msg.phaseStart = phaseStart
        msg.intermission = intermission
        msg.secondsRemaining = secondsRemaining
        hostFrame = msg.frame
        
        ' Send out the state of all players
        Dim a As Object
        a = JSArray.Create
        Dim i As Integer
        For i = 1 To UBound(players)
            Dim p As Player
            p.name = players(i).name
            p.cid = players(i).cid
            p.eid = players(i).eid
            p.x = GXEntityX(p.eid)
            p.y = GXEntityY(p.eid)
            p.vx = GXEntityVX(p.eid)
            p.vy = GXEntityVY(p.eid)
            p.seq = GXEntitySequence(p.eid)
            p.frame = GXEntityFrame(p.eid)
            p.animateSpeed = players(i).animateSpeed
            p.tags = players(i).tags
            p.hits = players(i).hits
            p.hitFrame = players(i).hitFrame
            p.disabled = players(i).disabled
            JSArray.Push a, p
        Next i
        msg.players = a
        
        ' Send out the state of all lasers
        a = JSArray.Create
        Dim bid As Integer
        For i = 1 To UBound(bullets)
            bid = bullets(i).eid
            If GXEntityVisible(bid) And GXEntityVX(bid) = 0 And GXEntityVY(bid) = 0 Then
                GXEntityVisible bid, GX_FALSE
                GXEntityPos bid, -100, -100
            ElseIf GXEntityX(bid) < 0 Or GXEntityY(bid) < 0 Or _
                   GXEntityX(bid) > GXMapColumns * GXTilesetWidth Or _
                   GXEntityY(bid) > GXMapRows * GXTilesetHeight Then
                ResetBullet bid
            End If
            Dim b As Bullet
            b.visible = GXEntityVisible(bid)
            b.x = GXEntityX(bid)
            b.y = GXEntityY(bid)
            b.vx = GXEntityVX(bid)
            b.vy = GXEntityVY(bid)
            b.seq = GXEntitySequence(bid)
            b.frame = GXEntityFrame(bid)
            JSArray.Push a, b
        Next i
        msg.lasers = a
        
        ' Set any sounds that have been triggered since the last frame
        msg.sounds = tsounds
        
        ' Sent the message to the server, which will in turn send it 
        ' out to each game client
        GXS.SendMessage MSG_UPDATE_PLAYERS, msg
        
        ' Clear the sounds list for the next frame
        JSArray.Clear tsounds
    End If

    If Sys.IsRunning Then
        Sys.SetTimeout @SendPlayerUpdates, 16
    Else
        GXS.LeaveGame
        GXSUI.PutMessage "You have left the game."
    End If
End Sub

' Add a new player to the current game
Sub AddPlayer (cid As String)
    Dim As Integer pcount, eid, idx
    pcount = UBound(players) + 1
    Redim Preserve players(pcount) As Player
    eid = GXEntityCreate("character.png", 20, 20, 4)
    GXEntityType eid, ETYPE_PLAYER
    GXEntityCollisionOffset eid, 3, 12, 4, 0
    players(pcount).eid = eid
    players(pcount).cid = cid
    players(pcount).direction = DIR_DOWN
    players(pcount).tags = 0
    players(pcount).hits = 0
    idx = Fix(Rnd*UBound(spawnPoints))+1
    GXEntityPos eid, spawnPoints(idx).x, spawnPoints(idx).y
    GXEntityFrameSet eid, 3, 1
    GXEntityMapLayer eid, 3
    pmap(cid) = players(pcount)
    pmap(eid) = players(pcount)
    Dim cstate As ControlState
    players(pcount).cstate = cstate
End Sub

Sub ResetPlayers
    Dim As Integer i, sidx
    For i = 1 To UBound(players)
        If players(i).disabled Then Continue
        sidx = Fix(Rnd*UBound(spawnPoints))+1
        GXEntityPos players(i).eid, spawnPoints(sidx).x, spawnPoints(sidx).y
        players(i).tags = 0
        players(i).hits = 0
        players(i).hitFrame = GXFrame
    Next i
End Sub

Sub DisablePlayer (p As Player)
    p.disabled = GX_TRUE
    GXEntityVisible p.eid, GX_FALSE
    GXEntityPos p.eid, -1000, -1000
    GXEntityVX p.eid, 0
    GXEntityVY p.eid, 0
End Sub

Sub OnStartHostGame (playerName As String, gameDesc As String)
    GXSUI.PutMessage "Connecting..."
    pname = playerName
    GXS.HostGame GAME_NAME, gameDesc
End Sub

Sub OnStartJoinGame (playerName As String, gameId As String)
    GXSUI.PutMessage "Connecting..."
    pname = playerName
    GXS.JoinGame gameId
End Sub

' ---------------------------------------------------------------------
' Game server events
' ---------------------------------------------------------------------
' This method is called once a new game has been created on the server
' in response to the GXS.HostGame method.
' We will create the initial player and start the game.
Sub OnHostGame (msg As Object)
    AddPlayer msg.cid
    players(1).name = pname
    GXSceneFollowEntity players(1).eid, GXSCENE_FOLLOW_ENTITY_CENTER
    started = GX_TRUE
    connecting = GX_FALSE
    phaseStart = Sys.TimeInMillis
    GXSUI.PutMessage "Game session started with id: " + GXS.SessionId 
End Sub

' This method is called when a client has joined the game in response
' to the GXS.JoinGame method.  It is sent to both the game host and back
' to the client which joined the game.
' If this is the host, we will add the new player to the game.
' If this is the client we will start the game and register the player 
' name with the host any other players that we have joined.
Sub OnJoinGame (msg As Object)
    If GXS.IsHost Then
        AddPlayer msg.cid
    Else
        started = GX_TRUE
        GXS.SendMessage MSG_REGISTER_PLAYER, pname
        connecting = GX_FALSE
    End If
End Sub

' This method is called on all game clients when a new player
' has joined the game
Sub OnRegisterPlayer (msg As Object)
    If GXS.IsHost Then pmap(msg.cid).name = msg.data
    GXSUI.PutMessage msg.data + " has joined the game!"
End Sub

' Called when a new chat message has been sent.
Sub OnChat (msg As Object)
    Dim As String sender
    sender = pmap(msg.cid).name
    GXSUI.PutChatMessage sender, msg.data
End Sub

' This is the main game update that is send out to all game clients
' each frame from the host. It includes the state of all player and
' bullet entities as well as any sounds that should be triggered.
Sub OnUpdatePlayers (msg As Object)
    If GXS.IsHost Then Exit Sub
    If Not started Then Exit Sub
    
    If Not intermission And msg.data.intermission Then ReSortPlayers
    hostFrame = msg.data.frame
    phaseStart = msg.data.phaseStart
    intermission = msg.data.intermission
    secondsRemaining = msg.data.secondsRemaining
    
    Dim a As Object
    a = msg.data.players
    Dim i As Integer
    For i = 1 To JSArray.Length(a)
        Dim p As Player
        p = JSArray.Item(a, i-1)
        If UBound(players) < i Then AddPlayer p.cid
        Dim As Integer eid
        eid = players(i).eid
        players(i).name = p.name
        players(i).tags = p.tags
        players(i).hits = p.hits
        players(i).hitFrame = p.hitFrame
        players(i).disabled = p.disabled
        GXEntityPos eid, p.x, p.y
        GXEntityVX eid, p.vx
        GXEntityVY eid, p.vy
        If p.animateSpeed Then        
            GXEntityAnimate eid, p.seq, p.animateSpeed
        Else
            GXEntityAnimateStop eid
            GXEntityFrameSet eid, p.seq, p.frame
        End If
        If players(i).cid = GXS.ClientId Then
            GXSceneFollowEntity players(i).eid, GXSCENE_FOLLOW_ENTITY_CENTER
        End If
    Next i
    
    a = msg.data.lasers
    Dim bid As Integer
    For i = 1 To JSArray.Length(a)
        Dim b As Bullet
        b = JSArray.Item(a, i-1)
        bid = bullets(i).eid
        GXEntityVisible bid, b.visible
        GXEntityPos bid, b.x, b.y
        GXEntityVX bid, b.vx
        GXEntityVY bid, b.vy
        GXEntityFrameSet bid, b.seq, b.frame
    Next i
    
    a = msg.data.sounds
    For i = 1 To JSArray.Length(a)
        Dim s As GameSound
        s = JSArray.Item(a, i-1)
        PlaySoundAt s
    Next i
End Sub

' Called when a client disconnects from the game
Sub OnClientDisconnect (msg As Object)
    Dim p As Player
    p = pmap(msg.cid)
    GXSUI.PutMessage p.name + " has left the game."
    DisablePlayer p
End Sub

' Called when the game host disconnects from the server
Sub OnHostDisconnect (msg As Object)
    Dim As Object oldHost, newHost
    oldHost = pmap(msg.cid)
    newHost = pmap(msg.hid)
    GXSUI.PutMessage "Host [" + oldHost.name + "] has disconnected."
    GXSUI.PutMessage newHost.name + " is now the host."
    DisablePlayer oldHost
End Sub

' Called when a general networking error occurs
Sub OnError
    If connecting Then
        GXSUI.PutMessage "Error connecting to server."
        connecting = GX_FALSE
        GXSceneStop
    Else
        'PutMessage "An unknown error has occurred."
        GXSUI.PutMessage "An unknown error has occurred."
    End If
End Sub

' This method is called on the game host when player control input
' state has been sent from a client.
Sub OnCtrlState (msg As Object)
    Dim p As Player
    p = pmap(msg.cid)
    If p <> undefined Then
        p.cstate = msg.data
    End If
End Sub

' This method is called when the connection to the game server
' has closed.
Sub OnClose (e As Object)
    If e.wasClean Then
        GXSUI.PutMessage "Connection closed."
    Else
        GXSUI.PutMessage "ERROR:[" + e.code + "]: " + e.reason
    End If
End Sub