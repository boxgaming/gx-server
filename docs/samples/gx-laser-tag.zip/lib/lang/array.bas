Export Create, Length, Item, Push, Clear, Sort

Function Length (a As Object)
    Length = 0
    If a.length Then Length = a.length
End Function

Function Item (a As Object, index As Integer)
$If Javascript Then
    Item = a[index]
$End If
End Function

Function Create (qbArray())
    Dim a As Object
$If Javascript Then
    a = [];
$End If
    If qbarray <> undefined Then
        Dim i As Integer
        For i = 1 To UBound(qbarray)
            Push a, qbarray(i)
        Next i
    End If
    Create = a
End Function

Sub Clear (a As Object)
    a.length = 0
End Sub

Sub Push (a As Object, value As Object)
$If Javascript Then
    a.push(value);
$End If
End Sub

Sub Sort (a As Object, sortFn As Function)
$If Javascript Then
    var fs = sortFn.toString();
    var bstart = fs.indexOf("{");
    var bend = fs.lastIndexOf("}");
    var compareFn = new Function("a", "b", fs.substring(bstart+1, bend-1));
    a.sort(compareFn);
$End If
End Sub