Export IsRunning, TimeInMillis

Function IsRunning
$If Javascript Then
    return QB.toBoolean(QB.running());
$End If
End Function

Function TimeInMillis
$If Javascript Then
    return Date.now();
$End If
End Function